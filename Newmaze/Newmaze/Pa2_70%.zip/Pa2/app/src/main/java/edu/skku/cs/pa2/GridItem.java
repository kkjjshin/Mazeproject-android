package edu.skku.cs.pa2;

public class GridItem {

    int num;
    int num_maze;

    public GridItem(int num, int num_maze){
        this.num = num;
        this.num_maze = num_maze;
    }



}
