package edu.skku.cs.pa2;

import android.content.Context;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.ArrayList;

public class GridViewAdapter extends BaseAdapter {
    private ArrayList<GridItem> items = new ArrayList<>();
    private Context mContext;

    public GridViewAdapter(Context mContext, ArrayList<GridItem> items){
        this.mContext = mContext;
        this.items = items;
    }



    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return items.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if(view == null){


            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.grid_item, viewGroup, false); //질문

            Log.d("comecomecome", String.valueOf(items.get(i).num));

            ImageView immgg = view.findViewById(R.id.imageView5);

            ImageView sub_img = view.findViewById(R.id.iv_sub);

            // num_maze에 따른 셀 식 만들기




            ConstraintLayout.LayoutParams parms = (ConstraintLayout.LayoutParams) immgg.getLayoutParams();
            //parms.width 및 height 식 즉, 마진포함하지 않은 셀의 너비







            Log.d("nummaze11: ", String.valueOf(items.get(i).num_maze));
            parms.width = (int)((float)(((float)350/(float) items.get(i).num_maze)*((float)450/(float)160)))-16;
            parms.height = parms.width;

            Log.d("firstsibal: ", String.valueOf((int)(350/items.get(i).num_maze)));
            Log.d("secondsibal: ", String.valueOf(((float)450/(float)160)));


            if(items.get(i).num == 8){
                parms.topMargin = 8;
                parms.bottomMargin = 0;
                parms.leftMargin = 0;
                parms.rightMargin = 0;
                parms.width +=16;
                parms.height += 8;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 4){
                parms.topMargin = 0;
                parms.bottomMargin = 0;
                parms.leftMargin = 8;
                parms.rightMargin = 0;
                parms.width += 8;
                parms.height += 16;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 1){
                parms.topMargin = 0;
                parms.bottomMargin = 0;
                parms.leftMargin = 0;
                parms.rightMargin = 8;
                parms.width +=8;
                parms.height += 16;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 2){
                parms.topMargin = 0;
                parms.bottomMargin = 8;
                parms.leftMargin = 0;
                parms.rightMargin = 0;
                parms.width += 16;
                parms.height += 8;

                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 10){
                parms.topMargin = 8;
                parms.bottomMargin = 8;
                parms.leftMargin = 0;
                parms.rightMargin = 0;
                parms.width += 16;
                immgg.setImageResource(R.drawable.user);
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 5){
                parms.topMargin = 0;
                parms.bottomMargin = 0;
                parms.leftMargin = 8;
                parms.rightMargin = 8;
                parms.height += 16;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 12){
                parms.topMargin = 8;
                parms.bottomMargin = 0;
                parms.leftMargin = 8;
                parms.rightMargin = 0;
                parms.width += 8;
                parms.height += 8;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 9){
                parms.topMargin = 8;
                parms.bottomMargin = 0;
                parms.leftMargin = 0;
                parms.rightMargin = 8;
                parms.width += 8;
                parms.height += 8;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 3){
                parms.topMargin = 0;
                parms.bottomMargin = 8;
                parms.leftMargin = 0;
                parms.rightMargin = 8;
                parms.width += 8;
                parms.height += 8;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 6){
                parms.topMargin = 0;
                parms.bottomMargin = 8;
                parms.leftMargin = 8;
                parms.rightMargin = 0;
                parms.width += 8;
                parms.height += 8;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 13){
                parms.topMargin = 8;
                parms.bottomMargin = 0;
                parms.leftMargin = 8;
                parms.rightMargin = 8;
                parms.height += 8;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 11){
                parms.topMargin = 8;
                parms.bottomMargin = 8;
                parms.leftMargin = 0;
                parms.rightMargin = 8;
                parms.width += 8;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 7){
                parms.topMargin = 0;
                parms.bottomMargin = 8;
                parms.leftMargin = 8;
                parms.rightMargin = 8;
                parms.height += 8;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 14){
                parms.topMargin = 8;
                parms.bottomMargin = 8;
                parms.leftMargin = 8;
                parms.rightMargin = 0;
                parms.width += 8;
                immgg.setLayoutParams(parms);
            }

            
            //984.375 350dp 를 px로 변환할시








           
            
            //height만 해결하면돼
            //어댑터에서는 이미지뷰 잘 걸리나, mazeactivity에서는 안됨

        }



        return view;
    }
}
