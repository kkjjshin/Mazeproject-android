package edu.skku.cs.pa2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MazeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maze);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");

        OkHttpClient client = new OkHttpClient();

        HttpUrl.Builder urlBuilder = HttpUrl.parse("http://115.145.175.57:10099/maze/map").newBuilder();
        urlBuilder.addQueryParameter("name",name);

        String url = urlBuilder.build().toString();

        Request req = new Request.Builder().url(url).build();

        GridView gv_maze = findViewById(R.id.gv_maze);

        client.newCall(req).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                final String myResponse = response.body().string();
                // myResponse 파싱하고 배열에 담아준 후, 배열 돌면서 items.add로 꽂아줌.

                String[] mazz = myResponse.split("n");
                for(int i=0; i<mazz.length;i++){
                    Log.d("heruare", mazz[i]);
                }

                int num_maze = mazz.length - 2;

                int[][] map_maze = new int[num_maze][num_maze];
                
                //num_maze에 map 정보담김
                for(int i=0; i<num_maze; i++){
                    for(int j=0; j<num_maze; j++){
                        String[] ak = mazz[i+1].split(" ");
                        map_maze[i][j] = Integer.parseInt(ak[j]);
                    }
                }
                
                

                for(int i=0; i<num_maze; i++){
                    for(int j=0; j<num_maze; j++){
                        Log.d("mapmaze: ", String.valueOf(map_maze[i][j]));
                    }
                }

                ArrayList<GridItem> items = new ArrayList<>();

                for(int i=0; i<num_maze; i++){
                    for(int j=0; j<num_maze; j++){
                        items.add(new GridItem(map_maze[i][j], num_maze));
                        Log.d("mapmaze: ", String.valueOf(map_maze[i][j]));
                    }
                }


                GridViewAdapter mAdapter = new GridViewAdapter(getApplicationContext(), items);

                MazeActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        LayoutInflater infl = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                        View vv = infl.inflate(R.layout.grid_item, null);

                        gv_maze.setNumColumns(num_maze);
                        Log.d("mazess",myResponse);
                        gv_maze.setAdapter(mAdapter);
                    }
                });
            }
        });

    }
}