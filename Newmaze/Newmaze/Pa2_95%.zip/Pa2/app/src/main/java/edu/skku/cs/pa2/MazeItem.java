package edu.skku.cs.pa2;

public class MazeItem {
    public String name;
    public String size;

    public MazeItem(String name, String size){
        this.name = name;
        this.size = size;
    }
}
