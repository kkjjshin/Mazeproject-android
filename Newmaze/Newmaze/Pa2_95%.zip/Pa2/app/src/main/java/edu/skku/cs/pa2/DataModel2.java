package edu.skku.cs.pa2;

public class DataModel2 {
    private String name;
    private String size;

    public String getName() {
        return name;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public void setName(String name) {
        this.name = name;
    }
}
