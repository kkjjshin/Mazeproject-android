package edu.skku.cs.pa2;

public class MapTF {
    int t;
    int b;
    int r;
    int l;

    public MapTF(int[][] cell){

    }

}
