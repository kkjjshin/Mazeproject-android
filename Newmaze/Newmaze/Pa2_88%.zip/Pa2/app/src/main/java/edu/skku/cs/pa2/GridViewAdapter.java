package edu.skku.cs.pa2;

import android.content.Context;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.ArrayList;

public class GridViewAdapter extends BaseAdapter {
    private ArrayList<GridItem> items = new ArrayList<>();
    private Context mContext;
    private int dpi;

    public GridViewAdapter(Context mContext, ArrayList<GridItem> items, int dpi){
        this.mContext = mContext;
        this.items = items;
        this.dpi = dpi;
    }



    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return items.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if(view == null){

            if(items.get(i).cango.equals("left")){
                Log.d("whybullshit", "dsfdfsdf");
            }
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.grid_item, viewGroup, false); //질문

            Log.d("comecomecome", String.valueOf(items.get(i).num));

            ImageView immgg = view.findViewById(R.id.imageView5);

            ImageView sub_img = view.findViewById(R.id.iv_sub); // 유저

            ConstraintLayout.LayoutParams parms = (ConstraintLayout.LayoutParams) immgg.getLayoutParams();
            //parms.width 및 height 식 즉, 마진포함하지 않은 셀의 너비

            Context context;







            Log.d("nummaze11: ", String.valueOf(items.get(i).num_maze));
            int half_m = (int)((((float)dpi/(float)160))*((float)3));
            int full_m = half_m*2;
            Log.d("half_m: ", String.valueOf(half_m));
            parms.width = (int)((float)(((float)350/(float) items.get(i).num_maze)*((float)dpi/(float)160)))-full_m;
            parms.height = parms.width;

            Log.d("firstsibal: ", String.valueOf((int)(350/items.get(i).num_maze)));
            Log.d("secondsibal: ", String.valueOf(((float)450/(float)160)));



            //유저 첫시작점 위치시킴
            if((items.get(i).cango.equals("right"))||(items.get(i).cango.equals("left"))||(items.get(i).cango.equals("top"))
                    ||(items.get(i).cango.equals("bottom"))){
                if(items.get(i).cango.equals("right")){
                    sub_img.setImageResource(R.drawable.user);
                    sub_img.setRotation(90);
                    sub_img.bringToFront(); //이미지 맨 앞에 둠
                    Log.d("lulululu_r: ", "hi");
                }
                else if(items.get(i).cango.equals("left")){
                    sub_img.setImageResource(R.drawable.user);
                    sub_img.setRotation(270);
                    sub_img.bringToFront(); //이미지 맨 앞에 둠
                    Log.d("lulululu_r: ", "hi");
                }
                else if(items.get(i).cango.equals("top")){
                    sub_img.setImageResource(R.drawable.user);
                    sub_img.bringToFront(); //이미지 맨 앞에 둠
                    Log.d("lulululu_r: ", "hi");
                }
                else if(items.get(i).cango.equals("bottom")){
                    sub_img.setImageResource(R.drawable.user);
                    sub_img.setRotation(180);
                    sub_img.bringToFront(); //이미지 맨 앞에 둠
                    Log.d("lulululu_r: ", "hi");
                }
            }
            else{
                sub_img.setImageResource(0);
                sub_img.bringToFront(); //이미지 맨 앞에 둠
            }





            if(i ==items.size()-1){
                sub_img.setImageResource(R.drawable.goal);
            }


            if(items.get(i).num == 8){
                parms.topMargin = half_m;
                parms.bottomMargin = 0;
                parms.leftMargin = 0;
                parms.rightMargin = 0;
                parms.width +=full_m;
                parms.height += half_m;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 4){
                parms.topMargin = 0;
                parms.bottomMargin = 0;
                parms.leftMargin = half_m;
                parms.rightMargin = 0;
                parms.width += half_m;
                parms.height += full_m;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 1){
                parms.topMargin = 0;
                parms.bottomMargin = 0;
                parms.leftMargin = 0;
                parms.rightMargin = half_m;
                parms.width +=half_m;
                parms.height += full_m;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 2){
                parms.topMargin = 0;
                parms.bottomMargin = half_m;
                parms.leftMargin = 0;
                parms.rightMargin = 0;
                parms.width += full_m;
                parms.height += half_m;

                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 10){
                parms.topMargin = half_m;
                parms.bottomMargin = half_m;
                parms.leftMargin = 0;
                parms.rightMargin = 0;
                parms.width += full_m;

                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 5){
                parms.topMargin = 0;
                parms.bottomMargin = 0;
                parms.leftMargin = half_m;
                parms.rightMargin = half_m;
                parms.height += full_m;

                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 12){
                parms.topMargin = half_m;
                parms.bottomMargin = 0;
                parms.leftMargin = half_m;
                parms.rightMargin = 0;
                parms.width += half_m;
                parms.height += half_m;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 9){
                parms.topMargin = half_m;
                parms.bottomMargin = 0;
                parms.leftMargin = 0;
                parms.rightMargin = half_m;
                parms.width += half_m;
                parms.height += half_m;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 3){
                parms.topMargin = 0;
                parms.bottomMargin = half_m;
                parms.leftMargin = 0;
                parms.rightMargin = half_m;
                parms.width += half_m;
                parms.height += half_m;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 6){
                parms.topMargin = 0;
                parms.bottomMargin = half_m;
                parms.leftMargin = half_m;
                parms.rightMargin = 0;
                parms.width += half_m;
                parms.height += half_m;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 13){
                parms.topMargin = half_m;
                parms.bottomMargin = 0;
                parms.leftMargin = half_m;
                parms.rightMargin = half_m;
                parms.height += half_m;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 11){
                parms.topMargin = half_m;
                parms.bottomMargin = half_m;
                parms.leftMargin = 0;
                parms.rightMargin = half_m;
                parms.width += half_m;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 7){
                parms.topMargin = 0;
                parms.bottomMargin = half_m;
                parms.leftMargin = half_m;
                parms.rightMargin = half_m;
                parms.height += half_m;
                immgg.setLayoutParams(parms);
            }
            else if(items.get(i).num == 14){
                parms.topMargin = half_m;
                parms.bottomMargin = half_m;
                parms.leftMargin = half_m;
                parms.rightMargin = 0;
                parms.width += half_m;
                immgg.setLayoutParams(parms);
            }

            
            //984.375 350dp 를 px로 변환할시








           
            
            //height만 해결하면돼
            //어댑터에서는 이미지뷰 잘 걸리나, mazeactivity에서는 안됨

        }



        return view;
    }
}
